import { ActionType, AlertMessageService } from '../../../_services/AlertMessageService';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { SetNotificationService } from '../_service/setnotification.service';
import { CreatenotificationComponent } from '../create/createnotification.component';
import { NotificationdetailsComponent } from '../details/notificationdetails.component';
import { ConfirmNotificationComponent } from './setnotifyconfirm.component';
import { environment } from '../../../../environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { IPlatformAlert } from '../_model/setnotification.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-setnotification',
  templateUrl: './setnotification.component.html',
  styleUrls: ['./setnotification.component.scss']
})
export class SetnotificationComponent implements OnInit {
  searchdata: string ='';
  listflag: boolean = false;
  selectedPage: any;
  public page = 0;
  public size = 9;
  public loading: boolean = false;
  initPage = 0;
  listPage = 0;
  public pageSize = environment.pageSize;
  setnotificationalertList:IPlatformAlert[]=[];
  filternotification:IPlatformAlert[]=[];
  filterListnotification:IPlatformAlert[]=[];
  contactdata:IPlatformAlert;
  dataSource = new MatTableDataSource<any>();
  displayColumns=['alertsName','channels','creditsMessage','expiringInDays','expiringMessage','actions']
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private dialog: MatDialog, private setNotifyservice: SetNotificationService, private translate: TranslateService,private router: Router, private alertMessage: AlertMessageService) { }

  ngOnInit() {
  this.getNotifications();

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.toLowerCase().trim();
    this.getListData({ pageIndex: this.listPage, pageSize: this.pageSize });
    this.dataSource.filterPredicate =
    (data: IPlatformAlert, filter: string) => data.alertsName == null ? false : data.alertsName.toLowerCase().indexOf(filter.toLowerCase()) > -1;
  }

  ngAfterViewInit() {
    setTimeout(() => { this.dataSource.sort = this.sort, this.dataSource.paginator = this.paginator });
  }

getNotifications(){
  this.loading = true;
  this.setNotifyservice.getPlatformAlerts().subscribe((response:IPlatformAlert[]) => {
    console.log("Response==>", response);
    if (response) {
      console.log("Response==>", response);
      this.setnotificationalertList = response;
      this.getData({ pageIndex: this.initPage, pageSize: this.pageSize });
      this.dataSource = new MatTableDataSource(this.setnotificationalertList);
      this.getListData({ pageIndex: this.listPage, pageSize: this.pageSize }); 
    }  
    this.loading = false;
  }, error => {
    let message = error.error.messages as string
    let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
    console.error("E-getNotifications==>", JSON.stringify(error));
    this.showAlert(errorMessage, ActionType.ERROR, error.status);
    this.loading = false;
   });
}
showAlert(error: any, action: ActionType, status: number = 0) {
  if (status == 401)
    this.router.navigate(['401']);
  else setTimeout(() => this.alertMessage.showAlert(error, action));
}

sortData() {
  this.dataSource.sort = this.sort
}
  loadList() {
   this.listPage=0;
   this.listflag = true;
   this.getListData({ pageIndex: this.listPage, pageSize: this.pageSize }); 
   this.dataSource.filterPredicate =
   (data: IPlatformAlert, filter: string) => data.alertsName.toLowerCase().indexOf(filter.toLowerCase()) > -1
  }

  loadGrid() {
    this.initPage=0;
    this.listflag = false;
    this.getData({ pageIndex: this.initPage, pageSize: this.pageSize });

  }

  getStatusConfig(data?: any): MatDialogConfig {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '500px';
    dialogConfig.disableClose = true;
    data ? dialogConfig.data = data : undefined;
    dialogConfig.disableClose = true;
    return dialogConfig;
  }

  getDialogConfig(data?: any): MatDialogConfig {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '35vw';
    dialogConfig.height = '95.5%';
    dialogConfig.panelClass = 'rightdailog';
    dialogConfig.position = { right: '0px', bottom: '0' };
    data ? dialogConfig.data = data : undefined;
    dialogConfig.disableClose = true;
    return dialogConfig;
  }

  getData(_pageData) {
    let index = 0;
    let startingIndex = _pageData.pageIndex * _pageData.pageSize;
    let endingIndex = startingIndex + _pageData.pageSize;
    this.selectedPage = _pageData.pageIndex;
    this.filternotification = this.setnotificationalertList.filter(() => {
      index++;
      return (index > startingIndex && index <= endingIndex) ? true : false;
    });
    this.initPage = _pageData.pageIndex;
    console.log("NotificationData::" + JSON.stringify(this.setnotificationalertList));
  }

  getListData(obj) {
    let index = 0,
    startingIndex = obj.pageIndex * obj.pageSize,
    endingIndex = startingIndex + obj.pageSize;
  console.log("this.notificationList=>", this.setnotificationalertList);
  this.filternotification = this.setnotificationalertList.filter(() => {
    index++;
    return (index > startingIndex && index <= endingIndex) ? true : false;
  });
  this.dataSource = new MatTableDataSource(this.setnotificationalertList);
  if(this.searchdata!=''){
    this.dataSource = new MatTableDataSource(this.setnotificationalertList);
    this.dataSource.filter = this.searchdata.toLowerCase().trim();
  }
  this.listPage = obj.pageIndex;
  }

  addNotification(){
    const dialogRef = this.dialog.open(CreatenotificationComponent, this.getDialogConfig());
    dialogRef.afterClosed().subscribe(result=>{
     if(result)
    this.getNotifications();
    });
  }

  editnotification(notifydetails){
    const dialogRef = this.dialog.open(CreatenotificationComponent, this.getDialogConfig(notifydetails));
    dialogRef.afterClosed().subscribe(result=>{
      if(result){
        this.getNotifications();
      }
    })
  }

  notificationDetails(notifydetails:IPlatformAlert){
    this.dialog.open(NotificationdetailsComponent, this.getDialogConfig(notifydetails));
  }

  deleteNotification(notifydetails){
    const dialogRef = this.dialog.open(ConfirmNotificationComponent, {
      width: '500px',
      data: "Do you want to delete Alert"+ ' \"' + notifydetails.notificationName+' \" ...?'
    });
  }

  notifyName(id){
    // const cntdata =[];
    // this.contactdata = this.setnotificationalertList.find(x => x.notificationId == id);
    // if(this.contactdata.contact.length > 0){
    //   this.contactdata.contact.forEach(contact => {
    //     cntdata.push(contact.name);
    //   });
    //   return cntdata;
    // }
  }

  notifyEmail(id){
    // const cntdata =[];
    // this.contactdata = this.setnotificationalertList.find(x => x.notificationId == id);
    // if(this.contactdata.contact.length > 0){
    //   this.contactdata.contact.forEach(contact => {
    //     cntdata.push(contact.email);
    //   });
    //   return cntdata;
    // }
  }
  
  notifyPhone(id){
//  const cntdata =[];
//  this.contactdata = this.setnotificationalertList.find(x => x.notificationId == id);
//  if(this.contactdata.contact.length > 0){
//  this.contactdata.contact.forEach(contact => {
//  cntdata.push(contact.phone);
//  });
//  return cntdata;
//  }
 }

}
