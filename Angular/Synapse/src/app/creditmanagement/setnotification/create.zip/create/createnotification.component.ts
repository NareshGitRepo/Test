import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AsyncValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import {IAlertDetail,  ISenderList, ApiResponse, IPlatformAlert } from '../_model/setnotification.model';
import { SetNotificationService } from '../_service/setnotification.service';
import { Observable } from 'rxjs';
import { ActionType, AlertMessageService } from '../../../_services/AlertMessageService';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-createnotification',
  templateUrl: './createnotification.component.html',
  styleUrls: ['./createnotification.component.scss']
})
export class CreatenotificationComponent implements OnInit {
  //notificationsForm: FormGroup;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  add = false;
  edit = false;
  isEditable: Boolean = false;
  msgCount: number;
  msgCount1: number;
  engLength: number = 1848;
  arbLength: number = 804;
  msglength: number = this.engLength;
  charcount = 0;
  charcount1 = 0;
  msgPlaceHolder: string = 'Message';
  oldmessage: string = '';
  _arabic = /[\u0621-\u064A]/;
  _unicode = /[^\u0000-\u007F]+/;
  format = /[~^\[\]{}|\\]/g;
  sms: any;
  createObj: IPlatformAlert;
  senderslist: ISenderList[] = [];
  flag: boolean = false
  patternEmail = /^(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/;

  //   alertslist = [{name:"Ramesh",email:"ramesh@test.com",mobile:"9912345678"},
  //  {name:"Mahesh",email:"mahesh@test.com",mobile:"9912345678",isEditable:false},
  //  {name:"Suresh",email:"suresh@test.com",mobile:"9912345678",isEditable:false}]
  alertslist:IAlertDetail[]= [];

  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<CreatenotificationComponent>,
    @Inject(MAT_DIALOG_DATA) public _editnotifydata: IPlatformAlert,private translate: TranslateService,
    private service: SetNotificationService, private cdRef: ChangeDetectorRef, private router: Router, private alertMessage: AlertMessageService) { }

  ngOnInit() {
    this.firstFormGroup = this.fb.group({
      notificationName: [null],
      validatePlatformAlertName: [this._editnotifydata != null ? this._editnotifydata.channels : null, [Validators.required], [AlertNameValidator(this.service, this._editnotifydata != null ? this._editnotifydata.channels : '', this._editnotifydata != null ? true : false)]],
      chemail: [false],
      chsms: [false],
      senderList: [null],
      days: [null, Validators.required],
      smstext: [null, Validators.required],
      creditsbelow: [null, Validators.required],
      credittext: [null, Validators.required]
    })
    this.secondFormGroup = this.fb.group({
      name: [null, Validators.required],
      email: [null,[Validators.required, Validators.pattern(this.patternEmail)]],
      phone: [null, Validators.required],
      tableData: [null, Validators.required]
    });
    if(this._editnotifydata){
      this.firstFormGroup.get('validatePlatformAlertName').clearValidators();
      this.firstFormGroup.get('validatePlatformAlertName').updateValueAndValidity();
    }
    this.firstFormGroup.controls.smstext.valueChanges.subscribe((smsText) => {
      this.messageCount(smsText);
    });
    this.firstFormGroup.controls.credittext.valueChanges.subscribe((credittext) => {
      this.messageCount1(credittext);
    });
    if (this.firstFormGroup.value.smstext != null) {
      this.messageCount(this.firstFormGroup.value.smstext);
    }
    if (this.firstFormGroup.value.credittext != null) {
      this.messageCount1(this.firstFormGroup.value.credittext);
    }
    this.getSenders();
  }
  smsChannelSelection(){
    console.log(this.firstFormGroup.value.chsms);
    if(this.firstFormGroup.value.chsms==true){
      this.firstFormGroup.get('senderList').setValidators([Validators.required]);
      this.firstFormGroup.get('senderList').updateValueAndValidity();
    }
    else{
      this.firstFormGroup.get('senderList').clearValidators();
      this.firstFormGroup.get('senderList').updateValueAndValidity()
    }
  }
  messageCount(smsText) {
    if (smsText) {
       this.msgPlaceHolder = this._arabic.test(smsText) ? 'MessageArbic' : (this._unicode.test(smsText) ? 'MessageUnicode' : 'MessageEnglish');
      this.charcount = smsText.length;
      if (this._unicode.test(smsText)) {
        this.msgCount = Math.ceil((this.charcount > 70 ? this.charcount : 67) / 67);
        this.msglength = this.arbLength;
        if (this.charcount > this.arbLength)
          this.firstFormGroup.get('smstext').setValue(this.firstFormGroup.value.smstext);
      }
      else {
        let formCahr = smsText.match(this.format);
        this.charcount += formCahr == null ? 0 : formCahr.length;
        this.msgCount = Math.ceil((this.charcount > 160 ? this.charcount : 153) / 153);
        this.msglength = this.engLength - (formCahr == null ? 0 : formCahr.length);
        if (this.charcount > this.engLength)
          this.firstFormGroup.get('smstext').setValue(this.firstFormGroup.value.smstext);
      }
      if (this.msgCount > 12) {
        this.firstFormGroup.get('smstext').setValue(this.oldmessage);
      }
      else
        this.oldmessage = smsText;
    }
    else {
      this.oldmessage = '';
      this.msgCount = 0;
      this.charcount = 0;
      this.msgPlaceHolder = 'Message';
    }
    this.cdRef.detectChanges();
  }
  messageCount1(creditText) {
    if (creditText) {
        this.msgPlaceHolder = this._arabic.test(creditText) ? 'MessageArbic' : (this._unicode.test(creditText) ? 'MessageUnicode' : 'MessageEnglish');
      this.charcount1 = creditText.length;
      if (this._unicode.test(creditText)) {
        this.msgCount1 = Math.ceil((this.charcount1 > 70 ? this.charcount1 : 67) / 67);
        this.msglength = this.arbLength;
        if (this.charcount1 > this.arbLength)
          this.firstFormGroup.get('credittext').setValue(this.firstFormGroup.value.credittext);
      }
      else {
        let formCahr = creditText.match(this.format);
        this.charcount1 += formCahr == null ? 0 : formCahr.length;
        this.msgCount1 = Math.ceil((this.charcount1 > 160 ? this.charcount1 : 153) / 153);
        this.msglength = this.engLength - (formCahr == null ? 0 : formCahr.length);
        if (this.charcount1 > this.engLength)
          this.firstFormGroup.get('credittext').setValue(this.firstFormGroup.value.credittext);
      }
      if (this.msgCount > 12) {
        this.firstFormGroup.get('credittext').setValue(this.oldmessage);
      }
      else
        this.oldmessage = creditText;
    }
    else {
      this.oldmessage = '';
      this.msgCount = 0;
      this.charcount1 = 0;
      this.msgPlaceHolder = 'Message';
    }
    this.cdRef.detectChanges();
  }
  addTableData(action?:boolean) {
    if(action){
    this.add = true;
    let canAdd: boolean = false;
    this.alertslist.forEach(obj => {
      if (obj.name != this.secondFormGroup.value.name && obj.emailId != this.secondFormGroup.value.email && obj.mobileNo != this.secondFormGroup.value.phone) {
        canAdd = true;
      }
      else {
        canAdd = false;
        this.showAlert("Your have entered Duplicate Data", ActionType.ERROR)
      }
    })
    if (canAdd || this.alertslist.length == 0) {
      this.alertslist.push({ name: this.secondFormGroup.value.name, emailId: this.secondFormGroup.value.email, mobileNo: this.secondFormGroup.value.phone});
      this.secondFormGroup.get('name').setValue(null);
      this.secondFormGroup.get('email').setValue(null);
      this.secondFormGroup.get('phone').setValue(null);
      this.secondFormGroup.get('tableData').setValue(true);
    }
  }
  else{
   
    this._editnotifydata.alertDetails.forEach(x => {
      this.alertslist.push({ platAlrtDetailsId: x.platAlrtDetailsId, name: x.name, mobileNo:x.mobileNo, emailId: x.emailId })
    });
    this.secondFormGroup.get('name').setValue(null);
    this.secondFormGroup.get('email').setValue(null);
    this.secondFormGroup.get('phone').setValue(null);
    this.secondFormGroup.get('tableData').setValue(this.alertslist);
  }
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }
  deleteTableData(alertslist) {
    let index: number = this.alertslist.findIndex(x => x.platAlrtDetailsId == alertslist.platformAlertsId);
    if (index !== -1) {
      this.alertslist.splice(index, 1);
    }
    if (this.alertslist.length == 0) {
      this.secondFormGroup.get('tableData').setValue(null)
    }
  }
  getSenders() {
    this.service.getAllActiveSenders().subscribe((result: ISenderList[]) => {
      if (result) {
        console.log("data", result);
        this.senderslist = result.filter(x => x.status == 1 && x.senderType != 2);
        console.log('senderslist=>', this.senderslist);
        if(this._editnotifydata){
           this.firstFormGroup.patchValue({
            notificationName:this._editnotifydata.alertsName,
            chemail: (this._editnotifydata.channels=='2' || this._editnotifydata.channels=="1,2")?true:false,
            chsms: (this._editnotifydata.channels=="1" || this._editnotifydata.channels=="1,2")?true:false,
            senderList: (this._editnotifydata.channels=="1"|| this._editnotifydata.channels=="1,2")? this._editnotifydata.senderId:null,
            days: this._editnotifydata.expiringInDays,
            smstext: this._editnotifydata.expiringMessage,
            creditsbelow:this._editnotifydata.creditsBelow,
            credittext: this._editnotifydata.creditsMessage
          });
          this.addTableData(false);
        }
      }
      error => {
        this.senderslist = [];
        let message = error.error.messages as string
        let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
        console.error("E-getSenders==>", JSON.stringify(error));
        this.showAlert(errorMessage, ActionType.ERROR, error.status);
      }
  })
}

  createnotification() {
    this.createObj = {
      alertsName: this.firstFormGroup.value.notificationName,
      alertDetails: this.alertslist,
      channels: this.firstFormGroup.value.chsms ? "1" : (this.firstFormGroup.value.chemail ? "2" : "1,2"),
      creditsBelow: this.firstFormGroup.value.creditsbelow,
      creditsMessage: this.firstFormGroup.value.credittext,
      expiringInDays: this.firstFormGroup.value.days,
      expiringMessage: this.firstFormGroup.value.smstext,
      senderId: this.firstFormGroup.value.senderList,
      status: 0
    }
    if(!this._editnotifydata){
    console.log("submitted Data:::", JSON.stringify(this.createObj));
      this.service.createPlatformAlert(this.createObj).subscribe((response: ApiResponse) => {
        console.log("response=>", response);
        if (response.status) {
          this.alertMessage.showAlert(response.message, ActionType.SUCCESS);
          this.dialogRef.close(response.status);

        } else {
          this.alertMessage.showAlert(response.message, ActionType.FAILED);
        }
      })
    }
    else{
      this.createObj.platformAlertsId=this._editnotifydata.platformAlertsId;
      this.service.updatePlatformAlert(this.createObj).subscribe((response: ApiResponse) => {
        console.log("response=>", response);
        if (response.status) {
          this.alertMessage.showAlert(response.message, ActionType.SUCCESS);
          this.dialogRef.close(response.status);

        } else {
          this.alertMessage.showAlert(response.message, ActionType.FAILED);
        }
      })
    }
    error => {

      this.senderslist = [];
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-setNotification==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
    }

  }
    
}



export function AlertNameValidator(service: SetNotificationService,name: string, action?: boolean): AsyncValidatorFn {
  return (control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
      if (action && name == (control.value as string).trim())
      return control.value != null ? service.validatePlatformAlertName((control.value as string).trim())
        .map(response => {
          console.log(response.status)
          return !response.status ? { invalid: true } : null
        }) : null;
    else
      return control.value != null ? service.validatePlatformAlertName((control.value as string).trim())
        .map(response => {
          console.log(response.status)
          return !response.status ? { invalid: true } : null
        }) : null;
  };
}
